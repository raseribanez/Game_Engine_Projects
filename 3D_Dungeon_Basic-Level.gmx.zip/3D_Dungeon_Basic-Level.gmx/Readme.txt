Ben Woodfield - raserppsprograms@gmail.com

A very Simple 3D Dungeon level
Developed by following a tutorial
Feel free to use this level as a template, or a learning aid
Runs with Gamamaker Studio - or YoYo Game engine. I 'think' it will run on Steam too


USE:
Run the file - (3D Dungeon Crawler Start.project.gmx)
Designed for Windows primarily

CONTROLS:
UP Arrow Key	=	Forward    
DOWN Arrow Key	=	Backward
LEFT Arrow Key	=	Turn Left
RIGHT Arrow Key	=	Turn Right

NOTE:
Very basic controls - pressing UP Arrow moves forward 1 space, 
you have to keep re-pressing to walk. So 1 press = 1 Step